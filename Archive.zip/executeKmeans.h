#ifndef EXECUTEKMEANS
#define EXECUTEKMEANS
#include "utils.h"

int kmeans(Matrix vectors, int k, int N, int d);


#endif
