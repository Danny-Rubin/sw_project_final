function run_wam() {
  echo "\nrunning: _wam\n"
  gcc -o c_executable ../spkmeans.c ../spkmeansmodule.c
  leaks --atExit --list -- ./c_executable wam ./example_jacobi.txt | grep "^Process"
  # cat outpudpudpud.txt
}

function run_ddg() {
  echo "\nrunning: ddg\n"
  gcc -o c_executable ../spkmeans.c ../spkmeansmodule.c
  leaks --atExit --list -- ./c_executable ddg ./example_jacobi.txt | grep "^Process"
  # cat outpudpudpud.txt
}

function run_lnorm() {
  echo "\nrunning: lnorm\n"
  gcc -o c_executable ../spkmeans.c ../spkmeansmodule.c
  leaks --atExit --list -- ./c_executable lnorm ./example_jacobi.txt | grep "^Process"
  # cat outpudpudpud.txt
}

function run_jacobi() {
  echo "\nrunning: jacobi\n"
  gcc -o c_executable ../spkmeans.c ../spkmeansmodule.c
  leaks --atExit --list -- ./c_executable lnorm ./example_jacobi.txt | grep "^Process"
  # cat outpudpudpud.txt
}


function run_all_memcheck() {
  #export MallocStackLogging=1
   run_jacobi && run_wam && run_ddg && run_lnorm
}

function tsiben() {
    echo "tsiben: \n"
    gcc -o c_executable ../spkmeans.c ../spkmeansmodule.c
    ./c_executable jacobi ./test_jacobi_lecture_13_input.txt > tsibout.txt
    diff -y tsibout.txt correct.txt
      # cat outpudpudpud.txt
}


function pythonInterface() {
    echo "run all python interface: \n"
    echo "remove shitty old build... \n"
    rm -rf build && rm mykmeanssp.cpython*
    echo "building extenstion... \n"
    python3 setup.py build_ext --inplace
    echo "run spk python input 1: \n"
    python3 spkmeans.py 3 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/input1.txt
    echo "run spk python input 2: \n"
    python3 spkmeans.py 3 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/input2.txt
    echo "run spk python input 3: \n"
    python3 spkmeans.py 3 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/input3.txt
    echo "run spk python input 4: \n"
    python3 spkmeans.py 3 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/input4.txt
    echo "run spk python input 5: \n"
    python3 spkmeans.py 3 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/input5.txt
    echo "run spk python input 6: \n"
    python3 spkmeans.py 3 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/input6.txt
    echo "run spk python input 7: \n"
    python3 spkmeans.py 3 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/input7.txt
    echo "#################################################"
        echo "#################################################"
        echo "#################################################"
        echo "#################################################"
        echo "run spk python BOZO spk_0: \n"
        python3 spkmeans.py 0 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/spk_0.txt
        echo "run spk python BOZO spk_1: \n"
        python3 spkmeans.py 2 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/spk_1.txt
        echo "run spk python BOZO spk_2 = 2: \n"
        python3 spkmeans.py 3 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/spk_2.txt
        echo "run spk python BOZO spk_3 = 2: \n"
        python3 spkmeans.py 5 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/spk_3.txt
        echo "run spk python BOZO spk_4 = 2: \n"
        python3 spkmeans.py 0 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/spk_4.txt
        echo "run spk python BOZO spk_5 = 2: \n"
        python3 spkmeans.py 0 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/spk_5.txt
        echo "run spk python BOZO spk_6: \n"
        python3 spkmeans.py 0 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/spk_6.txt
        echo "run spk python BOZO spk_7: \n"
        python3 spkmeans.py 30 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/spk_7.txt
        echo "run spk python BOZO spk_8: \n"
        python3 spkmeans.py 0 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/spk_8.txt
        echo "run spk python BOZO spk_9 = 2: \n"
        python3 spkmeans.py 0 spk /specific/a/home/cc/students/cs/noamavidor/sw_project/final_project/06_09/project_comprehensive_test/testfiles/spk_9.txt




#    gcc -o c_executable ../spkmeans.c ../spkmeansmodule.c
#    ./c_executable jacobi ./test_jacobi_lecture_13_input.txt > tsibout.txt
#    diff -y tsibout.txt correct.txt
      # cat outpudpudpud.txt
}
echo "test run on: " > output.txt
date "+%Y-%m-%d %H:%M:%S" >> output.txt
pythonInterface >> output.txt