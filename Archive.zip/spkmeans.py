import numpy as np
import pandas as pd
import sys
from os import remove
from os.path import exists
import mykmeanssp
DEBUG = False

### utils ###
def print_error():
    print("An Error Has Occurred\n")


def print_invalid_input():
    print("Invalid Input!\n")

# read file into numpy array, in case of error return false
def read_data(filename):
    try:
        df = pd.read_csv(filename, header=None)
        return df.to_numpy()
    except:
        print_error()
        return False

# perform kmeans++ initialization
def initialize_centroids(vectors: np.ndarray, k: int):
    try:
        N = vectors.shape[0]
        centroids_indices = np.zeros(k, dtype="int32")
        centroids_indices[0] = np.random.choice([i for i in range(N)])
        dists = np.zeros(N)
        probs = np.zeros(N)
        for i in range(1, k):
            for l in range(N):
                d = [np.square(np.linalg.norm(vectors[l] - vectors[centroids_indices[j]])) for j in range(i)]
                dists[l] = np.min(d)
            sum_dists = np.sum(dists)
            if sum_dists == 0:
                raise Exception("sum_dist is zero")
            probs = dists / sum_dists
            centroids_indices[i] = np.random.choice(N, p=probs)
        return centroids_indices
    except:
        print_error()
        return False


def create_c_input(vectors: np.ndarray, centroids_indices: np.ndarray):
    """
    This function creates a list of vectors (initialized centorids first) and writes it to file
    :param vectors: np.ndarray
    :param centroids_indices:np.ndarray
    :return: None
    """
    N = vectors.shape[0]
    try:
        sorted_vectors = [list(vectors[i]) for i in centroids_indices] + [list(vectors[i]) for i in range(N) if
                                                                          i not in centroids_indices]
        sorted_vectors = [[format(x, '.4f') for x in i] for i in sorted_vectors]
        if exists("c_input_file.txt"):
            remove("c_input_file.txt")
        with open("c_input_file.txt", 'w+') as c_input:
            for vec in sorted_vectors:
                c_input.write(",".join(vec) + "\n")

        return True
    except Exception as err:
        if DEBUG:
            print(err)
            print("problem in 'create c input'")
        print_error()
        return False

# output string indices and c output
def print_results(centroids_indices):
    try:
        print(",".join([str(i) for i in centroids_indices]))
        with open("c_output_file.txt", 'r') as c_out:
            file_contents = c_out.read()
            print(file_contents, end = "")
        return True
    except:
        if (DEBUG):
            print("problem in 'print results'")
        print_error()
        return False

# cleanup files after run
def finish_run():
    if exists("c_input_file.txt"):
        remove("c_input_file.txt")
    if exists("c_output_file.txt"):
        remove("c_output_file.txt")


def main():
    # main function - call c kmeans and c algorithms and python initialization from here
    np.random.seed(0)
    args = get_program_args()
    if args is False:
            return 1
    [k, goal, file_name] = args
    if exists("c_output_file.txt"):
        remove("c_output_file.txt")
    # call c extension
    result = mykmeanssp.pythonEntryPoint(k, goal, file_name, 1) 
    if (goal != "spk"):
        finish_run()
        return result
    vectors = read_data("c_output_file.txt")  # get ndarray of input vectors, sorted by index
    if vectors is False:
        return 1
    k = vectors.shape[1]
	# get indices of centroids that were chosen in kmeans ++
    centroids_indices = initialize_centroids(vectors, k)
    if centroids_indices is False:
        return 1
    # write to txt file list of vectors s.t first k vectors are init vectors
    if not create_c_input(vectors, centroids_indices):  
        return 1
    # second call to c extension- perform actual kmeans
    result = mykmeanssp.pythonEntryPoint(k, "spk", "c_input_file.txt", 2)
    if result == 0 and not print_results(centroids_indices):
        return 1
    # cleanup communication files
    finish_run()
    return result

# get user input cmd agrs and validate
# return false in case of error, else the read arguments as list
def get_program_args():
    try:
        assert len(sys.argv) == 4
        k = int(sys.argv[1])
        goal = sys.argv[2]
        file_name = sys.argv[3]
    except:
        print_invalid_input()
        return False
    return [k, goal, file_name]


if __name__ == '__main__':
    main()
